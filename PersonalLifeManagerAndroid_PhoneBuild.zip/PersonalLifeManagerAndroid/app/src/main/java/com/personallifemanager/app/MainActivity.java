package com.personallifemanager.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 79, 62));
        getWindow().setNavigationBarColor(Color.rgb(23, 79, 62));
        prefs = getSharedPreferences("personal_life_manager_data", MODE_PRIVATE);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 247, 244));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AppStorage(), "AndroidStorage");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppStorage {
        @JavascriptInterface
        public String loadData() {
            return prefs.getString("app_data_v2", "");
        }

        @JavascriptInterface
        public void saveData(String data) {
            prefs.edit().putString("app_data_v2", data).apply();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
