Personal Life Manager — Android project source

এই ZIP ফাইলটি APK নয়; এটি Android Studio-তে APK build করার project source।

অ্যাপের তথ্য:
- HTML অ্যাপটি assets/index.html-এ রাখা আছে।
- Android app-এর SharedPreferences-এ প্রতিটি সেভের সময় ডেটা রাখা হয়।
- ব্রাউজার ভার্সনে Local Storage fallback আছে।
- অ্যাপ uninstall বা Android Settings থেকে app data clear করলে স্থানীয় ডেটা মুছে যেতে পারে।
- তাই অ্যাপের Backup থেকে JSON ফাইল নিয়মিত ডাউনলোড/নিরাপদ জায়গায় রাখুন।
- এই project-এ cloud sync নেই।

APK বানাতে:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP extract করে Android Studio-তে PersonalLifeManager folder open করুন।
3. Gradle sync শেষ হতে দিন (ইন্টারনেট লাগতে পারে)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ তৈরি হবে।

গুরুত্বপূর্ণ: এই পরিবেশে Android SDK/Gradle build tool নেই এবং নেটওয়ার্কে SDK নামানো যায়নি, তাই এখানে APK binary compile করা সম্ভব হয়নি। Source project তৈরি করা হয়েছে।

শুধু ফোন দিয়ে APK বানানোর অতিরিক্ত পদ্ধতি (GitHub Actions):
1) github.com-এ অ্যাকাউন্ট খুলে New repository তৈরি করো (Public বা Private)।
2) ZIP ফাইলটি ফোনে Extract করো। Extract করা PersonalLifeManager ফোল্ডারের ভেতরের সব ফাইল/ফোল্ডার repository-র একই নামের PersonalLifeManager ফোল্ডারে আপলোড করতে হবে; .github ফোল্ডারটিও অবশ্যই আপলোড করবে।
3) GitHub repository-তে Actions ট্যাবে গিয়ে workflow অনুমতি চাইলে enable করো। “Build Personal Life Manager APK” workflow বেছে Run workflow চাপো।
4) Build সফল হলে ওই run-এর Artifacts অংশ থেকে PersonalLifeManager-debug-apk ডাউনলোড করো, ZIP extract করে app-debug.apk ইনস্টল করো। ফোনে “Install unknown apps” অনুমতি চাইতে পারে।
নোট: GitHub-এ সোর্স কোড আপলোড করতে হবে; ZIP ফাইলটিকে শুধু upload করলেই APK তৈরি হবে না। এই workflow দিয়ে APK build করার ব্যবস্থা যোগ করা হয়েছে, কিন্তু APK এখনো build/পরীক্ষা করা হয়নি।
